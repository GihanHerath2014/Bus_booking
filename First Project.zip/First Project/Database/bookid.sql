-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2018 at 01:38 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mysql`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookid`
--

CREATE TABLE IF NOT EXISTS `bookid` (
  `BookNo` double NOT NULL,
  `SF` varchar(90) NOT NULL,
  `GT` varchar(90) NOT NULL,
  `Date` varchar(70) NOT NULL,
  `BTime` varchar(70) NOT NULL,
  `Cost` varchar(70) NOT NULL,
  `BID` double NOT NULL,
  `SEno` varchar(80) NOT NULL,
  `Pname` varchar(80) NOT NULL,
  `Pmobile` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookid`
--

INSERT INTO `bookid` (`BookNo`, `SF`, `GT`, `Date`, `BTime`, `Cost`, `BID`, `SEno`, `Pname`, `Pmobile`) VALUES
(-2001463455, 'Colombo', 'Nittambuwa', 'Jan 19 ,2018', '08:30', 'Rs.798.72', 1, '    21, 14, 26', 'ss', '2'),
(-1870568345, 'Colombo', 'Kelanitissa', 'Dec 29 ,2017', '00:01', 'Rs.162.24', 12, '    17, 22, 26', 'Herath', '011-2563037'),
(-1723359588, 'Colombo', 'Nittambuwa', 'Dec 30 ,2017', '16:45', 'Rs.798.72', 2, '    21, 17, 18', 'Nayomal', '0777377313'),
(-1658356252, 'Colombo', 'Nittambuwa', 'Dec 22 ,2017', '08:30', 'Rs.266.24', 1, '    33', 'sfdggv', '16238'),
(-1458710202, 'Colombo', 'Nittambuwa', 'Dec 22 ,2017', '08:30', 'Rs.798.72', 1, '    25, 29, 30', 'sfget', '545567'),
(-927262485, 'Colombo', 'Nittambuwa', 'Dec 29 ,2017', '08:30', 'Rs.532.48', 1, '    17, 21', 'hakck', '1555388'),
(-757813450, 'Colombo', 'Colombo', 'Dec 14 ,2017', '01:06', 'Rs.0.0', 1, '    17, 22', 'dsv', '13'),
(-588682221, 'Colombo', 'Nittambuwa', 'Dec 30 ,2017', '08:30', 'Rs.532.48', 1, '    38, 39', 'hth', '5757'),
(-345698914, 'Colombo', 'Nittambuwa', 'Dec 30 ,2017', '16:45', 'Rs.798.72', 2, '    25, 29, 30', 'sefsf', '423533'),
(-251856063, 'Colombo', 'Nittambuwa', 'Jan 19 ,2018', '08:30', 'Rs.532.48', 1, '    34, 33', 'Niyomal', '077-7123456'),
(-215554106, '4TH Post/Biyagama Road', 'Thorana Junction', 'Dec 28 ,2017', '17:15', 'Rs.83.2', 46, '    09, 14', 'sfsgd wf', '2123'),
(256795407, 'Colombo', 'Nittambuwa', 'Dec 22 ,2017', '08:30', 'Rs.798.72', 1, '    17, 21, 22', 'hbk', '1655'),
(637810095, 'Colombo', 'Nittambuwa', 'Dec 30 ,2017', '16:45', 'Rs.532.48', 2, '    01, 05', 'uimk', '67890-67890'),
(1267060958, 'Colombo', 'Sangabodi Viharaya', 'Dec 29 ,2017', '08:40', 'Rs.773.75995', 3, '    25, 30, 33', 'vishal', '123456789'),
(1592933716, 'Colombo', 'Nittambuwa', 'Dec 28 ,2017', '08:30', 'Rs.798.72', 1, '    21, 25, 22', 'kumar', '071-3066486'),
(1663431291, 'Colombo', 'Colombo', 'Dec 23 ,2017', '01:06', 'Rs.0.0', 1, '    30, 33', 'dad', '43455');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookid`
--
ALTER TABLE `bookid`
 ADD PRIMARY KEY (`BookNo`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
