-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2018 at 01:40 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mysql`
--

-- --------------------------------------------------------

--
-- Table structure for table `busroot`
--

CREATE TABLE IF NOT EXISTS `busroot` (
  `FareNumber` int(10) NOT NULL,
  `FareStage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `busroot`
--

INSERT INTO `busroot` (`FareNumber`, `FareStage`) VALUES
(0, 'Colombo'),
(1, 'Maligawatta'),
(2, 'Kelanitissa'),
(3, '4TH Post/Biyagama Road'),
(4, 'Thorana Junction'),
(5, 'Kelaniya University'),
(6, 'Kiribathgoda'),
(7, 'Mahara Junction'),
(8, 'Kadawatha'),
(9, 'Gonahena Junction'),
(10, 'Indigahamulla Junction'),
(11, 'Kirillawala'),
(12, 'Tracmo Junction'),
(13, 'Mudungoda'),
(14, 'Miriswatta'),
(15, 'Yakkala'),
(16, 'Aluthgama'),
(17, 'Kalagedihena'),
(18, 'Thihariya'),
(19, 'Sangabodi Viharaya'),
(20, 'Nittambuwa');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
