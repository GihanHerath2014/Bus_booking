-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2018 at 01:39 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mysql`
--

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE IF NOT EXISTS `bus` (
  `Id` int(70) NOT NULL,
  `bus` text NOT NULL,
  `Fr` text NOT NULL,
  `Tt` text NOT NULL,
  `Tm` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`Id`, `bus`, `Fr`, `Tt`, `Tm`) VALUES
(1, 'NUWANTHA', 'Colombo', 'Nittambuwa', ' 08:30'),
(2, 'CBS', 'Colombo', 'Nittambuwa', ' 16:45'),
(3, 'WICKRAMASINGHE', 'Colombo', 'Sangabodi Viharaya', ' 08:40'),
(4, 'RATHNA & SON', 'Colombo', 'Yakkala', ' 08:00'),
(5, 'RATHNA & SON', 'Yakkala', 'Colombo', ' 19:30'),
(6, 'CBS', 'Nittambuwa', 'Colombo', ' 10:00'),
(7, 'NUWANTHA', 'Nittambuwa', 'Colombo', ' 11:00'),
(8, 'LANKA MATHA', 'Mudungoda', 'Colombo', ' 07:30'),
(9, 'LANKA MATHA', '4TH Post/Biyagama Road', 'Nittambuwa', ' 12:45'),
(10, 'CG TRAVALS', 'Aluthgama', 'Colombo', ' 18:10'),
(11, 'CG TRAVALS', 'Mudungoda', 'Aluthgama', ' 11:45'),
(12, '', 'Colombo', 'Colombo', ' 01:39');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
