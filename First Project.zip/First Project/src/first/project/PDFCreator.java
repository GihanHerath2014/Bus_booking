/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package first.project;

import com.qoppa.pdfWriter.PDFDocument;
import com.qoppa.pdfWriter.PDFGraphics;
import com.qoppa.pdfWriter.PDFPage;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;

/**
 *
 * @author Gihan
 */
public class PDFCreator {
    public static void main (String [] args)
    {
        try
        {
            // Create a document and a page in default Locale format
            PDFDocument pdfDoc = new PDFDocument();
            PDFPage newPage = pdfDoc.createPage(new PageFormat());
            
            // Draw to the page
////            Graphics2D g3d = newPage.createGraphics();
////            g3d.setFont (PDFGraphics.HELVETICA.deriveFont(18f));
////            g3d.drawString("Luxury Bus Services", 150, 90);
            Graphics2D g2d = newPage.createGraphics();
           
            g2d.setFont (PDFGraphics.HELVETICA.deriveFont(12f));
            g2d.drawString("Luxury Bus Services", 150, 90);
            g2d.drawString("Ticket Number :"+"",70,120);
            g2d.drawString("Staring From :"+"",70,140);
            g2d.drawString("Going To :"+"",70,160);
            g2d.drawString("Date of Junery :"+"",70,180);
            g2d.drawString("Bus Time :"+"",70,200);
            g2d.drawString("Book bu agent :"+"",70,220);
            g2d.drawString("Total Cost of Ticket :"+"",70,240);
            g2d.drawString("Bus ID :"+"",70,260);
            g2d.drawString("Passenger's information :",150,290);
            g2d.drawString("Seat Number :"+"",70,310);
            g2d.drawString("Passenger Name :"+"",70,330);
            g2d.drawString("Mobile Number :"+"",70,350);
            g2d.drawString(" :"+"",70,120);
            // Add the page to the document and save it
            pdfDoc.addPage(newPage);
            pdfDoc.saveDocument("output.pdf");
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }
    }
}
