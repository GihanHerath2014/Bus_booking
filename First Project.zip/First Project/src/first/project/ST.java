/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package first.project;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Gihan
 */
public class ST extends javax.swing.JFrame {

    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    String selectedTime = "";
    String selectedBus = "";
    boolean btn1 = true;
    boolean btn2 = true;
    boolean btn3 = true;
    boolean btn4 = true;
    boolean btn5 = true;
    boolean btn6 = true;
    boolean btn7 = true;
    boolean btn8 = true;
    boolean btn9 = true;
    boolean btn10 = true;
    boolean btn11 = true;
    boolean btn12 = true;
    boolean btn13 = true;
    boolean btn14 = true;
    boolean btn15 = true;
    boolean btn16 = true;
    boolean btn17 = true;
    boolean btn18 = true;
    boolean btn19 = true;
    boolean btn20 = true;
    boolean btn21 = true;
    boolean btn22 = true;
    boolean btn23 = true;
    boolean btn24 = true;
    boolean btn25 = true;
    boolean btn26 = true;
    boolean btn27 = true;
    boolean btn28 = true;
    boolean btn29 = true;
    boolean btn30 = true;
    boolean btn31 = true;
    boolean btn32 = true;
    boolean btn33 = true;
    boolean btn34 = true;
    boolean btn35 = true;
    boolean btn36 = true;
    boolean btn37 = true;
    boolean btn38 = true;
    boolean btn39 = true;
    boolean btn40 = true;
    boolean btn41 = true;

    /**
     * Creates new form ST2
     */
    public ST() {
        initComponents();
        FillCombo22();
      srr();
    }

    private void getReservedSeats(String busName) {
        allSeatsEnable();
        ResultSet rs = null;
        String result = "";
        Connection conn = null;
        Statement pst = null;
        String Se = "SELECT SeatNo FROM reservation r join bus b on r.busId=b.Id WHERE b.Bus='" + busName + "' And r.reserved='1' And r.Date='" + dt.getText() + "'";
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "");
            pst = conn.createStatement();
            rs = pst.executeQuery(Se);
            while (rs.next()) {
                String seatNumber = rs.getString("SeatNo");
                switch (seatNumber) {
                    case "1":
                        b1.setEnabled(false);
                        break;
                    case "2":
                        b2.setEnabled(false);
                        break;
                    case "3":
                        b3.setEnabled(false);
                        break;
                    case "4":
                        b4.setEnabled(false);
                        break;
                    case "5":
                        b5.setEnabled(false);
                        break;
                    case "6":
                        b6.setEnabled(false);
                        break;
                    case "7":
                        b7.setEnabled(false);
                        break;
                    case "8":
                        b8.setEnabled(false);
                        break;
                    case "9":
                        b9.setEnabled(false);
                        break;
                    case "10":
                        b10.setEnabled(false);
                        break;
                    case "11":
                        b11.setEnabled(false);
                        break;
                    case "12":
                        b12.setEnabled(false);
                        break;
                    case "13":
                        b13.setEnabled(false);
                        break;
                    case "14":
                        b14.setEnabled(false);
                        break;
                    case "15":
                        b15.setEnabled(false);
                        break;
                    case "16":
                        b16.setEnabled(false);
                        break;
                    case "17":
                        b17.setEnabled(false);
                        break;
                    case "18":
                        b18.setEnabled(false);
                        break;
                    case "19":
                        b19.setEnabled(false);
                        break;
                    case "20":
                        b20.setEnabled(false);
                        break;
                    case "21":
                        b21.setEnabled(false);
                        break;
                    case "22":
                        b22.setEnabled(false);
                        break;
                    case "23":
                        b23.setEnabled(false);
                        break;
                    case "24":
                        b24.setEnabled(false);
                        break;
                    case "25":
                        b25.setEnabled(false);
                    case "26":
                        b26.setEnabled(false);
                        break;
                    case "27":
                        b27.setEnabled(false);
                        break;
                    case "28":
                        b28.setEnabled(false);
                        break;
                    case "29":
                        b29.setEnabled(false);
                    case "30":
                        b30.setEnabled(false);
                        break;
                    case "31":
                        b31.setEnabled(false);
                        break;
                    case "32":
                        b32.setEnabled(false);
                        break;
                    case "33":
                        b33.setEnabled(false);
                        break;
                    case "34":
                        b34.setEnabled(false);
                        break;
                    case "35":
                        b35.setEnabled(false);
                        break;
                    case "36":
                        b36.setEnabled(false);
                        break;
                    case "37":
                        b37.setEnabled(false);
                        break;
                    case "38":
                        b38.setEnabled(false);
                        break;
                    case "39":
                        b39.setEnabled(false);
                        break;
                    case "40":
                        b40.setEnabled(false);
                        break;
                    case "41":
                        b41.setEnabled(false);
                        break;

                }
            }
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        b1 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b39 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        b13 = new javax.swing.JButton();
        b14 = new javax.swing.JButton();
        b18 = new javax.swing.JButton();
        b20 = new javax.swing.JButton();
        b38 = new javax.swing.JButton();
        b37 = new javax.swing.JButton();
        b41 = new javax.swing.JButton();
        b24 = new javax.swing.JButton();
        b34 = new javax.swing.JButton();
        b15 = new javax.swing.JButton();
        b17 = new javax.swing.JButton();
        b19 = new javax.swing.JButton();
        b16 = new javax.swing.JButton();
        b36 = new javax.swing.JButton();
        b21 = new javax.swing.JButton();
        b22 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        b30 = new javax.swing.JButton();
        b33 = new javax.swing.JButton();
        b9 = new javax.swing.JButton();
        b10 = new javax.swing.JButton();
        b11 = new javax.swing.JButton();
        b29 = new javax.swing.JButton();
        b28 = new javax.swing.JButton();
        b12 = new javax.swing.JButton();
        b25 = new javax.swing.JButton();
        b26 = new javax.swing.JButton();
        b27 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        b40 = new javax.swing.JButton();
        b23 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        b31 = new javax.swing.JButton();
        b35 = new javax.swing.JButton();
        b32 = new javax.swing.JButton();
        Back = new javax.swing.JButton();
        Next = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        From1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        To1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        dt = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        SSN = new javax.swing.JLabel();
        dr = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Id12 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        sn1 = new javax.swing.JLabel();
        One_Charge = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Select Bus from the list & click load  :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(91, 37, 222, 30));

        jComboBox1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 41, 347, -1));

        jButton1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jButton1.setText("Load");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(696, 40, 83, -1));

        b1.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b1.setText("01");
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        getContentPane().add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 250, -1, 25));

        b2.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b2.setText("02");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        getContentPane().add(b2, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 281, -1, 25));

        b39.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b39.setText("39");
        b39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b39ActionPerformed(evt);
            }
        });
        getContentPane().add(b39, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 310, -1, 25));

        b4.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b4.setText("04");
        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });
        getContentPane().add(b4, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 374, -1, 25));

        b13.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b13.setText("13");
        b13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b13ActionPerformed(evt);
            }
        });
        getContentPane().add(b13, new org.netbeans.lib.awtextra.AbsoluteConstraints(279, 250, -1, 25));

        b14.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b14.setText("14");
        b14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b14ActionPerformed(evt);
            }
        });
        getContentPane().add(b14, new org.netbeans.lib.awtextra.AbsoluteConstraints(279, 281, -1, 25));

        b18.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b18.setText("18");
        b18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b18ActionPerformed(evt);
            }
        });
        getContentPane().add(b18, new org.netbeans.lib.awtextra.AbsoluteConstraints(336, 281, -1, 25));

        b20.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b20.setText("20");
        b20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b20ActionPerformed(evt);
            }
        });
        getContentPane().add(b20, new org.netbeans.lib.awtextra.AbsoluteConstraints(336, 374, -1, 25));

        b38.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b38.setText("38");
        b38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b38ActionPerformed(evt);
            }
        });
        getContentPane().add(b38, new org.netbeans.lib.awtextra.AbsoluteConstraints(621, 281, -1, 25));

        b37.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b37.setText("37");
        b37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b37ActionPerformed(evt);
            }
        });
        getContentPane().add(b37, new org.netbeans.lib.awtextra.AbsoluteConstraints(621, 250, -1, 25));

        b41.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b41.setText("41");
        b41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b41ActionPerformed(evt);
            }
        });
        getContentPane().add(b41, new org.netbeans.lib.awtextra.AbsoluteConstraints(621, 374, -1, 25));

        b24.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b24.setText("24");
        b24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b24ActionPerformed(evt);
            }
        });
        getContentPane().add(b24, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 374, -1, 25));

        b34.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b34.setText("34");
        b34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b34ActionPerformed(evt);
            }
        });
        getContentPane().add(b34, new org.netbeans.lib.awtextra.AbsoluteConstraints(564, 281, -1, 25));

        b15.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b15.setText("15");
        b15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b15ActionPerformed(evt);
            }
        });
        getContentPane().add(b15, new org.netbeans.lib.awtextra.AbsoluteConstraints(279, 343, -1, 25));

        b17.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b17.setText("17");
        b17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b17ActionPerformed(evt);
            }
        });
        getContentPane().add(b17, new org.netbeans.lib.awtextra.AbsoluteConstraints(336, 250, -1, 25));

        b19.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b19.setText("19");
        b19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b19ActionPerformed(evt);
            }
        });
        getContentPane().add(b19, new org.netbeans.lib.awtextra.AbsoluteConstraints(336, 343, -1, 25));

        b16.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b16.setText("16");
        b16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b16ActionPerformed(evt);
            }
        });
        getContentPane().add(b16, new org.netbeans.lib.awtextra.AbsoluteConstraints(279, 374, -1, 25));

        b36.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b36.setText("36");
        b36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b36ActionPerformed(evt);
            }
        });
        getContentPane().add(b36, new org.netbeans.lib.awtextra.AbsoluteConstraints(564, 374, -1, 25));

        b21.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b21.setText("21");
        b21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b21ActionPerformed(evt);
            }
        });
        getContentPane().add(b21, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 250, -1, 25));

        b22.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b22.setText("22");
        b22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b22ActionPerformed(evt);
            }
        });
        getContentPane().add(b22, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 281, -1, 25));

        b5.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b5.setText("05");
        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });
        getContentPane().add(b5, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 250, -1, 25));

        b6.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b6.setText("06");
        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });
        getContentPane().add(b6, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 281, -1, 25));

        b7.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b7.setText("07");
        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });
        getContentPane().add(b7, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 343, -1, 25));

        b30.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b30.setText("30");
        b30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b30ActionPerformed(evt);
            }
        });
        getContentPane().add(b30, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 281, -1, 25));

        b33.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b33.setText("33");
        b33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b33ActionPerformed(evt);
            }
        });
        getContentPane().add(b33, new org.netbeans.lib.awtextra.AbsoluteConstraints(564, 250, -1, 25));

        b9.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b9.setText("09");
        b9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b9ActionPerformed(evt);
            }
        });
        getContentPane().add(b9, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 250, -1, 25));

        b10.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b10.setText("10");
        b10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b10ActionPerformed(evt);
            }
        });
        getContentPane().add(b10, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 281, -1, 25));

        b11.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b11.setText("11");
        b11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b11ActionPerformed(evt);
            }
        });
        getContentPane().add(b11, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 343, -1, 25));

        b29.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b29.setText("29");
        b29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                b29MouseClicked(evt);
            }
        });
        b29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b29ActionPerformed(evt);
            }
        });
        getContentPane().add(b29, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 250, -1, 25));

        b28.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b28.setText("28");
        b28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b28ActionPerformed(evt);
            }
        });
        getContentPane().add(b28, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 374, -1, 25));

        b12.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b12.setText("12");
        b12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b12ActionPerformed(evt);
            }
        });
        getContentPane().add(b12, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 374, -1, 25));

        b25.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b25.setText("25");
        b25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b25ActionPerformed(evt);
            }
        });
        getContentPane().add(b25, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 250, -1, 25));

        b26.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b26.setText("26");
        b26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b26ActionPerformed(evt);
            }
        });
        getContentPane().add(b26, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 281, -1, 25));

        b27.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b27.setText("27");
        b27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b27ActionPerformed(evt);
            }
        });
        getContentPane().add(b27, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 343, -1, 25));

        b3.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b3.setText("03");
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });
        getContentPane().add(b3, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 343, -1, 25));

        b40.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b40.setText("40");
        b40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b40ActionPerformed(evt);
            }
        });
        getContentPane().add(b40, new org.netbeans.lib.awtextra.AbsoluteConstraints(621, 343, -1, 25));

        b23.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b23.setText("23");
        b23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b23ActionPerformed(evt);
            }
        });
        getContentPane().add(b23, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 343, -1, 25));

        b8.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b8.setText("08");
        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });
        getContentPane().add(b8, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 374, -1, 25));

        b31.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b31.setText("31");
        b31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b31ActionPerformed(evt);
            }
        });
        getContentPane().add(b31, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 343, -1, 25));

        b35.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b35.setText("35");
        b35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b35ActionPerformed(evt);
            }
        });
        getContentPane().add(b35, new org.netbeans.lib.awtextra.AbsoluteConstraints(564, 343, -1, 25));

        b32.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        b32.setText("32");
        b32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b32ActionPerformed(evt);
            }
        });
        getContentPane().add(b32, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 374, -1, 25));

        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        getContentPane().add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 417, 131, -1));

        Next.setText("Next");
        Next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextActionPerformed(evt);
            }
        });
        getContentPane().add(Next, new org.netbeans.lib.awtextra.AbsoluteConstraints(617, 406, 151, -1));

        jLabel2.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("From :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 102, 75, -1));

        From1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        From1.setText(" ");
        getContentPane().add(From1, new org.netbeans.lib.awtextra.AbsoluteConstraints(91, 102, 164, -1));

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("To :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(261, 102, 52, -1));

        To1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        To1.setText(" ");
        getContentPane().add(To1, new org.netbeans.lib.awtextra.AbsoluteConstraints(319, 102, 166, -1));

        jLabel6.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("D.O.J :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(495, 102, 45, -1));

        dt.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        dt.setText(" ");
        getContentPane().add(dt, new org.netbeans.lib.awtextra.AbsoluteConstraints(546, 102, 95, -1));

        jLabel3.setFont(new java.awt.Font("Californian FB", 0, 13)); // NOI18N
        jLabel3.setText("Selected Seat Numbers :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(336, 171, -1, -1));
        getContentPane().add(SSN, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 175, 91, -1));

        dr.setText(" ");
        getContentPane().add(dr, new org.netbeans.lib.awtextra.AbsoluteConstraints(51, 252, 51, -1));

        jButton2.setText("Reset");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(279, 216, 108, -1));

        jLabel5.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel5.setText("Bus ID :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(651, 103, -1, -1));

        Id12.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Id12.setText(" ");
        getContentPane().add(Id12, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 103, 68, -1));

        jLabel7.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel7.setText("Charge for one  Ticket :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 171, -1, -1));

        sn1.setText("   ");
        getContentPane().add(sn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(466, 171, 300, -1));

        One_Charge.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        One_Charge.setText(" ");
        getContentPane().add(One_Charge, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 90, -1));

        jLabel8.setFont(new java.awt.Font("Calibri", 3, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 0, 0));
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 129, 500, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        //b1.setBackground(Color.yellow);
        // b1.setEnabled(false);
        while (btn1) {
            b1.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 01");
            } else {
                sn1.setText(selected + ", 01");
            }
            btn1 = false;
        }

    }//GEN-LAST:event_b1ActionPerformed

    private void b39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b39ActionPerformed

        while (btn39) {
            b39.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 39");
            } else {
                sn1.setText(selected + ", 39");
            }
            btn39 = false;
        }


    }//GEN-LAST:event_b39ActionPerformed

    private void b13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b13ActionPerformed
        while (btn13) {
            b13.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 13");
            } else {
                sn1.setText(selected + ", 13");
            }
            btn13 = false;
        }
    }//GEN-LAST:event_b13ActionPerformed

    private void b18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b18ActionPerformed
        while (btn18) {
            b18.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 18");
            } else {
                sn1.setText(selected + ", 18");
            }
            btn18 = false;
        }
    }//GEN-LAST:event_b18ActionPerformed

    private void b38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b38ActionPerformed
        while (btn38) {
            b38.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 38");
            } else {
                sn1.setText(selected + ", 38");
            }
            btn38 = false;
        }
    }//GEN-LAST:event_b38ActionPerformed

    private void b41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b41ActionPerformed
        while (btn41) {
            b41.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 41");
            } else {
                sn1.setText(selected + ", 41");
            }
            btn41 = false;
        }
    }//GEN-LAST:event_b41ActionPerformed

    private void b34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b34ActionPerformed
        while (btn34) {
            b34.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 34");
            } else {
                sn1.setText(selected + ", 34");
            }
            btn34 = false;
        }
    }//GEN-LAST:event_b34ActionPerformed

    private void b17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b17ActionPerformed
        while (btn17) {
            b17.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 17");
            } else {
                sn1.setText(selected + ", 17");
            }
            btn17 = false;
        }
    }//GEN-LAST:event_b17ActionPerformed

    private void b16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b16ActionPerformed
        while (btn16) {
            b16.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 16");
            } else {
                sn1.setText(selected + ", 16");
            }
            btn16 = false;
        }
    }//GEN-LAST:event_b16ActionPerformed

    private void b21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b21ActionPerformed
        while (btn21) {
            b21.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 21");
            } else {
                sn1.setText(selected + ", 21");
            }
            btn21 = false;
        }
    }//GEN-LAST:event_b21ActionPerformed

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        while (btn5) {
            b5.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 05");
            } else {
                sn1.setText(selected + ", 05");
            }
            btn5 = false;
        }
    }//GEN-LAST:event_b5ActionPerformed

    private void b30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b30ActionPerformed
        while (btn30) {
            b30.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 30");
            } else {
                sn1.setText(selected + ", 30");
            }
            btn30 = false;
        }
    }//GEN-LAST:event_b30ActionPerformed

    private void b9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b9ActionPerformed
        while (btn9) {
            b9.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 09");
            } else {
                sn1.setText(selected + ", 09");
            }
            btn9 = false;
        }
    }//GEN-LAST:event_b9ActionPerformed

    private void b11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b11ActionPerformed
        while (btn11) {
            b11.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 11");
            } else {
                sn1.setText(selected + ", 11");
            }
            btn11 = false;
        }
    }//GEN-LAST:event_b11ActionPerformed

    private void b29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b29ActionPerformed
        if (btn29) {
            b29.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 29");
            } else {
                sn1.setText(selected + ", 29");
            }
            btn29 = false;
        }
    }//GEN-LAST:event_b29ActionPerformed

    private void b28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b28ActionPerformed
        while (btn28) {
            b28.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 28");
            } else {
                sn1.setText(selected + ", 28");
            }
            btn28 = false;
        }
    }//GEN-LAST:event_b28ActionPerformed

    private void b25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b25ActionPerformed
        while (btn25) {
            b25.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 25");
            } else {
                sn1.setText(selected + ", 25");
            }
            btn25 = false;
        }
    }//GEN-LAST:event_b25ActionPerformed

    private void b27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b27ActionPerformed
        while (btn27) {
            b27.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 27");
            } else {
                sn1.setText(selected + ", 27");
            }
            btn27 = false;
        }
    }//GEN-LAST:event_b27ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        while (btn3) {
            b3.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 03");
            } else {
                sn1.setText(selected + ", 03");
            }
            btn3 = false;
        }
    }//GEN-LAST:event_b3ActionPerformed

    private void b23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b23ActionPerformed
        while (btn23) {
            b23.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 23");
            } else {
                sn1.setText(selected + ", 23");
            }
            btn23 = false;
        }
    }//GEN-LAST:event_b23ActionPerformed

    private void b35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b35ActionPerformed
        while (btn35) {
            b35.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 35");
            } else {
                sn1.setText(selected + ", 35");
            }
            btn35 = false;
        }
    }//GEN-LAST:event_b35ActionPerformed

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
        while (btn7) {
            b7.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 07");
            } else {
                sn1.setText(selected + ", 07");
            }
            btn7 = false;
        }
    }//GEN-LAST:event_b7ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        // b2.setBackground(Color.GRAY);
        while (btn2) {
            b2.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 02");
            } else {
                sn1.setText(selected + ", 02");
            }
            btn2 = false;
        }
    }//GEN-LAST:event_b2ActionPerformed

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        this.setVisible(false);
        Resevation RS = new Resevation();
        RS.setVisible(true);
    }//GEN-LAST:event_BackActionPerformed

    private void NextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextActionPerformed
        this.setVisible(false);
        ST2 st = new ST2();
        ST2.StartingFrom2.setText(this.From1.getText());
        ST2.GoingTo2.setText(this.To1.getText());
        ST2.date3.setText(this.dt.getText());
        ST2.SeatNo.setText(this.sn1.getText());
        ST2.BusId.setText(this.Id12.getText());
        ST2.Time = selectedTime;
         int count = (int) this.sn1.getText().chars().filter(ch -> ch == ',').count();
         count++;
        float perPerson = Float.parseFloat(One_Charge.getText().substring(3));
         float charge=count*perPerson;
      ST2.Total.setText("Rs."+String.valueOf(charge));
//        String pp=
//        ST2.Total.setText;
        st.setVisible(true);
    }//GEN-LAST:event_NextActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    
        String selectedCombobox = jComboBox1.getSelectedItem().toString();
        String selectedValue = selectedCombobox.split("-")[0].trim();
        Id12.setText(selectedValue);
        String selectedBus = selectedCombobox.split("-")[1].split("@")[0].trim();
        selectedTime = selectedCombobox.split("-")[1].split("@")[1].trim();
        getReservedSeats(selectedBus);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        while (btn4) {
            b4.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 04");
            } else {
                sn1.setText(selected + ", 04");
            }
            btn4 = false;
        }
    }//GEN-LAST:event_b4ActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        while (btn6) {
            b6.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 06");
            } else {
                sn1.setText(selected + ", 06");
            }
            btn6 = false;
        }
    }//GEN-LAST:event_b6ActionPerformed

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
        while (btn8) {
            b8.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 08");
            } else {
                sn1.setText(selected + ", 08");
            }
            btn8 = false;
        }
    }//GEN-LAST:event_b8ActionPerformed

    private void b10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b10ActionPerformed
        while (btn10) {
            b10.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 10");
            } else {
                sn1.setText(selected + ", 10");
            }
            btn10 = false;
        }
    }//GEN-LAST:event_b10ActionPerformed

    private void b12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b12ActionPerformed
        while (btn12) {
            b12.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 12");
            } else {
                sn1.setText(selected + ", 12");
            }
            btn12 = false;
        }
    }//GEN-LAST:event_b12ActionPerformed

    private void b14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b14ActionPerformed
        while (btn14) {
            b14.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 14");
            } else {
                sn1.setText(selected + ", 14");
            }
            btn14 = false;
        }
    }//GEN-LAST:event_b14ActionPerformed

    private void b15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b15ActionPerformed
        while (btn15) {
            b15.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 15");
            } else {
                sn1.setText(selected + ", 15");
            }
            btn15 = false;
        }
    }//GEN-LAST:event_b15ActionPerformed

    private void b19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b19ActionPerformed
        while (btn19) {
            b19.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 19");
            } else {
                sn1.setText(selected + ", 19");
            }
            btn19 = false;
        }
    }//GEN-LAST:event_b19ActionPerformed

    private void b20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b20ActionPerformed
        while (btn20) {
            b20.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 20");
            } else {
                sn1.setText(selected + ", 20");
            }
            btn20 = false;
        }
    }//GEN-LAST:event_b20ActionPerformed

    private void b22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b22ActionPerformed
        while (btn22) {
            b22.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 22");
            } else {
                sn1.setText(selected + ", 22");
            }
            btn22 = false;
        }
    }//GEN-LAST:event_b22ActionPerformed

    private void b24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b24ActionPerformed
        while (btn24) {
            b24.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 24");
            } else {
                sn1.setText(selected + ", 24");
            }
            btn24 = false;
        }
    }//GEN-LAST:event_b24ActionPerformed

    private void b26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b26ActionPerformed
        while (btn26) {
            b26.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 26");
            } else {
                sn1.setText(selected + ", 26");
            }
            btn26 = false;
        }
    }//GEN-LAST:event_b26ActionPerformed

    private void b31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b31ActionPerformed
        while (btn31) {
            b31.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 31");
            } else {
                sn1.setText(selected + ", 31");
            }
            btn31 = false;
        }
    }//GEN-LAST:event_b31ActionPerformed

    private void b32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b32ActionPerformed
        while (btn32) {
            b32.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 32");
            } else {
                sn1.setText(selected + ", 32");
            }
            btn32 = false;
        }
    }//GEN-LAST:event_b32ActionPerformed

    private void b33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b33ActionPerformed
        while (btn33) {
            b33.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 33");
            } else {
                sn1.setText(selected + ", 33");
            }
            btn33 = false;
        }
    }//GEN-LAST:event_b33ActionPerformed

    private void b36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b36ActionPerformed
        while (btn36) {
            b36.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 36");
            } else {
                sn1.setText(selected + ", 36");
            }
            btn36 = false;
        }
    }//GEN-LAST:event_b36ActionPerformed

    private void b37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b37ActionPerformed
        while (btn37) {
            b37.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 37");
            } else {
                sn1.setText(selected + ", 37");
            }
            btn37 = false;
        }
    }//GEN-LAST:event_b37ActionPerformed

    private void b40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b40ActionPerformed
        while (btn40) {
            b40.setBackground(Color.yellow);
            String selected = sn1.getText();

            if (selected.trim().length() == 0) {
                sn1.setText(selected + " 40");
            } else {
                sn1.setText(selected + ", 40");
            }
            btn40 = false;
        }
    }//GEN-LAST:event_b40ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            String a1=From1.getText();
            String c1=To1.getText();
            String d1=dt.getText();
           String e1=Id12.getText();
            String f1=One_Charge.getText();
           int g1=jComboBox1.getSelectedIndex();
         
            this.setVisible(false);
            
           
             
        ST GT= new ST() ;
        GT.From1.setText(a1);
        GT.To1.setText(c1);
        GT.dt.setText(d1);
       GT.Id12.setText(e1);
        GT.One_Charge.setText(f1);
        
       //FillCombo22();
        
        GT.jComboBox1.setSelectedIndex(g1);
        
        ST2ReserveSeats(GT);
      // String e1=Id12.getText();
       GT.Id12.setText(e1);
        //jComboBox1.setSelectedItem(y1);
        GT.setVisible(true);
        


       
        sn1.setText(" ");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void b29MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b29MouseClicked
        // TODO add your handling code here:
         
    }//GEN-LAST:event_b29MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ST.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ST.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ST.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ST.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ST().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    public static javax.swing.JLabel From1;
    private javax.swing.JLabel Id12;
    private javax.swing.JButton Next;
    public static javax.swing.JLabel One_Charge;
    private javax.swing.JLabel SSN;
    public static javax.swing.JLabel To1;
    private javax.swing.JButton b1;
    private javax.swing.JButton b10;
    private javax.swing.JButton b11;
    private javax.swing.JButton b12;
    private javax.swing.JButton b13;
    private javax.swing.JButton b14;
    private javax.swing.JButton b15;
    private javax.swing.JButton b16;
    private javax.swing.JButton b17;
    private javax.swing.JButton b18;
    private javax.swing.JButton b19;
    private javax.swing.JButton b2;
    private javax.swing.JButton b20;
    private javax.swing.JButton b21;
    private javax.swing.JButton b22;
    private javax.swing.JButton b23;
    private javax.swing.JButton b24;
    private javax.swing.JButton b25;
    private javax.swing.JButton b26;
    private javax.swing.JButton b27;
    private javax.swing.JButton b28;
    private javax.swing.JButton b29;
    private javax.swing.JButton b3;
    private javax.swing.JButton b30;
    private javax.swing.JButton b31;
    private javax.swing.JButton b32;
    private javax.swing.JButton b33;
    private javax.swing.JButton b34;
    private javax.swing.JButton b35;
    private javax.swing.JButton b36;
    private javax.swing.JButton b37;
    private javax.swing.JButton b38;
    private javax.swing.JButton b39;
    private javax.swing.JButton b4;
    private javax.swing.JButton b40;
    private javax.swing.JButton b41;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JButton b9;
    private javax.swing.JButton dr;
    public static javax.swing.JLabel dt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    public static javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel sn1;
    // End of variables declaration//GEN-END:variables


    private void allSeatsEnable() {
        b1.setEnabled(true);
        b2.setEnabled(true);
        b3.setEnabled(true);
        b4.setEnabled(true);
        b5.setEnabled(true);
        b6.setEnabled(true);
        b7.setEnabled(true);
        b8.setEnabled(true);
        b9.setEnabled(true);
        b10.setEnabled(true);
        b11.setEnabled(true);
        b12.setEnabled(true);
        b13.setEnabled(true);
        b14.setEnabled(true);
        b15.setEnabled(true);
        b16.setEnabled(true);
        b17.setEnabled(true);
        b18.setEnabled(true);
        b19.setEnabled(true);
        b20.setEnabled(true);
        b21.setEnabled(true);
        b22.setEnabled(true);
        b23.setEnabled(true);
        b24.setEnabled(true);
        b25.setEnabled(true);
        b26.setEnabled(true);
        b27.setEnabled(true);
        b28.setEnabled(true);
        b29.setEnabled(true);
        b30.setEnabled(true);
        b31.setEnabled(true);
        b32.setEnabled(true);
        b33.setEnabled(true);
        b34.setEnabled(true);
        b35.setEnabled(true);
        b36.setEnabled(true);
        b37.setEnabled(true);
        b38.setEnabled(true);
        b39.setEnabled(true);
        b40.setEnabled(true);
        b41.setEnabled(true);



        boolean btn1 = true;
        boolean btn2 = true;
        boolean btn3 = true;
        boolean btn4 = true;
        boolean btn5 = true;
        boolean btn6 = true;
        boolean btn7 = true;
        boolean btn8 = true;
        boolean btn9 = true;
        boolean btn10 = true;
        boolean btn11 = true;
        boolean btn12 = true;
        boolean btn13 = true;
        boolean btn14 = true;
        boolean btn15 = true;
        boolean btn16 = true;
        boolean btn17 = true;
        boolean btn18 = true;
        boolean btn19 = true;
        boolean btn20 = true;
        boolean btn21 = true;
        boolean btn22 = true;
        boolean btn23 = true;
        boolean btn24 = true;
        boolean btn25 = true;
        boolean btn26 = true;
        boolean btn27 = true;
        boolean btn28 = true;
        boolean btn29 = true;
        boolean btn30 = true;
        boolean btn31 = true;
        boolean btn32 = true;
        boolean btn33 = true;
        boolean btn34 = true;
        boolean btn35 = true;
        boolean btn36 = true;
        boolean btn37 = true;
        boolean btn38 = true;
        boolean btn39 = true;
        boolean btn40 = true;
        boolean btn41 = true;

    }

    public void FillCombo22() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "");
            String sww = "SELECT * FROM  bus WHERE Fr='" + Resevation.StartingFrom.getSelectedItem() + "' AND Tt='" + Resevation.GoingTo.getSelectedItem() + "'";
            pst = conn.prepareStatement(sww);
            fill();
          
            

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }
        
    public void fill() throws SQLException {
        rs = pst.executeQuery();
        //jComboBox1.removeAllItems();

        while (rs.next()) {
            String asd = rs.getString("bus");
            String stime = rs.getString("Tm");
            String id = rs.getString("Id");
            //String ooo=stime.substring(10, 16);
            jComboBox1.addItem(id + "-" + asd + "  @  " + stime);

        }

    }
    
    private void ST2ReserveSeats(ST GT){
        allSeatsEnable();
         String selectedCombobox = this.jComboBox1.getSelectedItem().toString();
        String selectedValue = selectedCombobox.split("-")[0].trim();
        Id12.setText(selectedValue);
        selectedBus = selectedCombobox.split("-")[1].split("@")[0].trim();
        selectedTime = selectedCombobox.split("-")[1].split("@")[1].trim();
       // ResultSet rs = null;
        String result = "";
        Connection conn = null;
        Statement pst = null;
        String Se = "SELECT SeatNo FROM reservation r join bus b on r.busId=b.Id WHERE b.Bus='" + selectedBus + "' And r.reserved='1'";
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "");
            pst = conn.createStatement();
            rs = pst.executeQuery(Se);
            while (rs.next()) {
                String seatNumber = rs.getString("SeatNo");
                switch (seatNumber) {
                    case "1":
                        b1.setEnabled(false);
                        break;
                    case "2":
                        b2.setEnabled(false);
                        break;
                    case "3":
                        b3.setEnabled(false);
                        break;
                    case "4":
                        b4.setEnabled(false);
                        break;
                    case "5":
                        b5.setEnabled(false);
                        break;
                    case "6":
                        b6.setEnabled(false);
                        break;
                    case "7":
                        b7.setEnabled(false);
                        break;
                    case "8":
                        b8.setEnabled(false);
                        break;
                    case "9":
                        b9.setEnabled(false);
                        break;
                    case "10":
                        b10.setEnabled(false);
                        break;
                    case "11":
                        b11.setEnabled(false);
                        break;
                    case "12":
                        b12.setEnabled(false);
                        break;
                    case "13":
                        b13.setEnabled(false);
                        break;
                    case "14":
                        b14.setEnabled(false);
                        break;
                    case "15":
                        b15.setEnabled(false);
                        break;
                    case "16":
                        b16.setEnabled(false);
                        break;
                    case "17":
                        b17.setEnabled(false);
                        break;
                    case "18":
                        b18.setEnabled(false);
                        break;
                    case "19":
                        b19.setEnabled(false);
                        break;
                    case "20":
                        b20.setEnabled(false);
                        break;
                    case "21":
                        b21.setEnabled(false);
                        break;
                    case "22":
                        b22.setEnabled(false);
                        break;
                    case "23":
                        b23.setEnabled(false);
                        break;
                    case "24":
                        b24.setEnabled(false);
                        break;
                    case "25":
                        b25.setEnabled(false);
                    case "26":
                        b26.setEnabled(false);
                        break;
                    case "27":
                        b27.setEnabled(false);
                        break;
                    case "28":
                        b28.setEnabled(false);
                        break;
                    case "29":
                        b29.setEnabled(false);
                    case "30":
                        b30.setEnabled(false);
                        break;
                    case "31":
                        b31.setEnabled(false);
                        break;
                    case "32":
                        b32.setEnabled(false);
                        break;
                    case "33":
                        b33.setEnabled(false);
                        break;
                    case "34":
                        b34.setEnabled(false);
                        break;
                    case "35":
                        b35.setEnabled(false);
                        break;
                    case "36":
                        b36.setEnabled(false);
                        break;
                    case "37":
                        b37.setEnabled(false);
                        break;
                    case "38":
                        b38.setEnabled(false);
                        break;
                    case "39":
                        b39.setEnabled(false);
                        break;
                    case "40":
                        b40.setEnabled(false);
                        break;
                    case "41":
                        b41.setEnabled(false);
                        break;

                }
            }
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }

    private void srr(){
          if(jComboBox1.getSelectedItem()==null ){
                jLabel8.setText(" Sorry....... \n We don't have bus in this route");
              Next.setEnabled(false);
              jButton1.setEnabled(false);
              b1.setEnabled(false);
        b2.setEnabled(false);
        b3.setEnabled(false);
        b4.setEnabled(false);
        b5.setEnabled(false);
        b6.setEnabled(false);
        b7.setEnabled(false);
        b8.setEnabled(false);
        b9.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b13.setEnabled(false);
        b14.setEnabled(false);
        b15.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b20.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b23.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b27.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b34.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b37.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b41.setEnabled(false);
        dr.setEnabled(false);
      jButton2.setEnabled(false);
              
            }
    }
}
